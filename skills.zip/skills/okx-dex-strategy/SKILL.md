---
name: okx-dex-strategy
description: "Limit-order strategy trading on OKX Agentic Wallet. Use this skill when the user wants to place a price-triggered limit order (buy a dip, take profit, stop loss, chase a high), cancel one or more pending orders, list active or historical orders, or resume orders that have been suspended by SA TEE upgrades. Distinct from okx-dex-swap (market orders, immediate execution at the best available aggregated price). Strategy orders are stored on the Agentic Wallet TEE and execute automatically when the user-defined trigger fires. Triggers (English): limit order, place limit order, buy at price, sell when price reaches, take profit at, stop loss at, chase high, buy dip, cancel order, cancel all orders, my orders, list orders, active orders, suspended orders, resume orders, recover suspended orders, trader mode, agentic limit order. Triggers (中文): 限价单, 挂单, 触发价, 抄底, 抄底买入, 止盈, 止损, 追涨, 撤单, 取消订单, 取消所有挂单, 查看订单, 我的订单, 活跃订单, 暂停的订单, 恢复挂起, 恢复挂起订单, Trader Mode, Agentic 限价单."
license: MIT
metadata:
  author: okx
  version: "0.1.0-phase1"
  homepage: "https://web3.okx.com"
---

# Onchain OS DEX Strategy (Phase 1)

4 P0 subcommands that wrap the Agentic Wallet limit-order surface — `create-limit`, `cancel`, `list`, `resume`. SA activation (Trader Mode upgrade / re-upgrade) is performed transparently by the CLI when the BE returns `UPGRADE_REQUIRED`; the skill does not need to expose that detail.

## Pre-flight Checks

> Read `../okx-agentic-wallet/_shared/preflight.md`. If that file does not exist, fall back to `_shared/preflight.md`. Strategy endpoints require an authenticated Agentic Wallet session — confirm login before running any subcommand.

## Output language convention (applies to every section below)

The agent's reply to the user MUST match the user's conversation language. The tables and example phrases in this skill use English as the canonical reference (`Buy Dip`, `Active`, `If the trigger condition is not met within 7 days, this order auto-expires.`); when the user is conversing in Chinese (or another language), the agent translates these phrases at output time — e.g. `Buy Dip → 抄底`, `Active → 挂单中`, `Cancelled → 已取消`. Never:
- mix languages in one label (e.g. `Buy Dip(抄底)` is forbidden — pick one),
- expose the underlying enum name (`BUY_DIP`) or CLI flag value (`buy_dip` / `cancelled`) to the user,
- pass through the CLI's raw `statusLabel` string verbatim when the user is conversing in Chinese — translate it.

CHASE_HIGH is intentionally surfaced as **Buy Above** (not "Chase High") in English; in Chinese it renders as `追涨`. The skill defines the semantic identity; the agent picks the user's-language phrasing. SPEEDING_UP (-4) was removed 2026-05-08 — not a valid filter or display value.

## Boundary vs `okx-dex-swap`

| User intent | Skill |
|---|---|
| "Swap X for Y now" / "Buy 0.5 ETH with USDC" | `okx-dex-swap` (market order, immediate execution) |
| "Buy ETH if it dips to $2000" / "Sell when ETH hits $5000" / "Take profit at X" / "Stop loss at Y" | this skill (price-triggered limit order) |
| "Cancel my pending order" | this skill |
| "What limit orders do I have?" | this skill |

If the venue is named explicitly (Uniswap, PancakeSwap, Raydium, Curve, ...) → re-route to `okx-dapp-discovery`. This skill is for OKX-aggregated limit orders only.

## Command Index

### 1. `onchainos strategy create-limit`

Place a single price-triggered limit order.

```
onchainos strategy create-limit \
  --chain-id <id|alias> \
  --from-token <address> \
  --to-token <address> \
  --amount <decimal-string> \
  --type <buy_dip|take_profit|stop_loss|chase_high> \
  [--trigger-price <usd>] \
  [--trigger-rate <ratio>] \
  [--slippage <value>] \
  [--direction <buy|sell|all>] \
  [--expires-in <secs>] \
  [--format human|json]
```

| Flag | Required | Notes |
|---|---|---|
| `--chain-id` | Y | Chain id or alias: `1`, `solana`, `bsc`, `arbitrum`, `base`, `xlayer` |
| `--from-token` | Y | Sell-side token contract address |
| `--to-token` | Y | Buy-side token contract address |
| `--amount` | Y | Amount of `from_token` to sell (string, no precision loss) |
| `--type` | Y | `buy_dip` / `take_profit` / `stop_loss` / `chase_high` (case-insensitive; `-` and `_` interchangeable) |
| `--trigger-price` | one of two | USD trigger price (Advanced mode) |
| `--trigger-rate` | one of two | Exchange-rate trigger (mutex with `--trigger-price`) |
| `--slippage` | N | Slippage tolerance in percent. Default `15` (= 15%). Pass the percent as a plain number — the CLI converts to BE wire format (divides by 100, e.g. `20` → `"0.2"`). When the user says "slippage 20" / "slippage 20%" / "use 20% slippage" — all map to `--slippage 20`. |
| `--direction` | N | Default derived from `--type` (BUY_DIP / CHASE_HIGH → buy; TAKE_PROFIT / STOP_LOSS → sell) |
| `--expires-in` | N | Seconds; default 604800 (7 days) |
| `--format` | N | `human` (default) prints a wait-then-requery hint; `json` emits `{ok:true,data:{orderId,status,statusLabel,estimatedWaitTime,eventCursor}}` |

**Output (human):**
```
Order created (id=<orderId>). status=<label>. estimatedWaitTime=<n>s.
After ~<n>s, run: onchainos strategy list --order-id <orderId>
```

**Solana orders return `estimatedWaitTime=0`** — the followup line is suppressed and the order is queryable immediately.

> Slippage interpretation reminder (no echo from CLI): `--slippage` input is in **percent units** — `0.05` = 0.05% (wire `"0.0005"`), NOT 5%. To set 5% slippage, pass `--slippage 5`. The skill / agent should convey this to the user at input time; the CLI itself does not echo a confirmation line.

#### Supported chains (Phase 1, locked)

Strategy orders are only supported on these 6 chains. Any other chain MUST be rejected upfront by the agent — do not call `create-limit` and do not even open the Step 1 confirmation.

| chainIndex | Name | `--chain-id` aliases |
|---|---|---|
| 1 | Ethereum | `ethereum`, `eth`, `1` |
| 56 | BSC | `bsc`, `56` |
| 196 | X Layer | `xlayer`, `196` |
| 501 | Solana | `solana`, `sol`, `501` |
| 8453 | Base | `base`, `8453` |
| 42161 | Arbitrum | `arbitrum`, `arb`, `42161` |

**Pre-flight rule (agent)**: when the user mentions a chain, resolve it to its chainIndex and check this list. If the chain is **not** in the table (e.g. Polygon `137`, Optimism `10`, Avalanche `43114`, Linea `59144`, Sui `784`, Tron `195`, ...), respond directly with:

> Strategy orders are only supported on Ethereum / BSC / X Layer / Solana / Base / Arbitrum right now. `<requested chain>` is not supported — pick one of these to continue.

Do NOT proceed to Step 1 confirmation. Do NOT call the CLI. The CLI also defends against this (validates against the same 6-chain whitelist before BE), but the agent catching it earlier saves a round trip and gives a clearer message tied to the user's exact phrasing.

#### `strategyType` enum (BaseOrderStrategyTypeEnum, locked)

| Int value | Enum name | Default direction | CLI `--type` value | Display label | Semantics |
|---|---|---|---|---|---|
| 2 | BUY_DIP | BUY (0) | `buy_dip` | Buy Dip | Buy when market price falls to trigger |
| 3 | TAKE_PROFIT | SELL (1) | `take_profit` | Take Profit | Sell when market price rises to trigger |
| 4 | STOP_LOSS | SELL (1) | `stop_loss` | Stop Loss | Sell when market price falls to trigger |
| 5 | CHASE_HIGH | BUY (0) | `chase_high` | Buy Above | Buy when market price rises above trigger (display label is `Buy Above`, NOT `Chase High`) |

The CLI maps `--type buy_dip` to `strategyType=2` (BE wire field) internally; the agent never passes the integer, only the `--type` string value.

> The "Display label" column is the human-readable text the agent should surface to the user — never expose the enum name (`BUY_DIP`) or the CLI flag value (`buy_dip`) directly. Note CHASE_HIGH renders as **"Buy Above"**, not "Chase High".

#### Strategy type derivation (Agent must follow)

The agent must NOT let the user dictate `strategyType` directly; instead derive it from `(direction, trigger price vs current price)`:

1. **Decide direction (buy / sell)** — parse user intent ("buy" / "ape in" / "snap up" → buy; "sell" / "take profit" / "stop loss" / "exit" → sell).
2. **Fetch current price** — call `onchainos market price --chain <chain> --address <token>`, read `data[0].price`. For BUY direction use the to-token's current price; for SELL direction use the from-token's current price.
3. **Compare trigger vs current** and pick `strategyType` per the table:

| Direction | trigger vs current | Inferred strategyType | CLI `--type` | Display label |
|---|---|---|---|---|
| buy | trigger < current | BUY_DIP (2) | `buy_dip` | Buy Dip |
| buy | trigger ≥ current | CHASE_HIGH (5) | `chase_high` | Buy Above |
| sell | trigger > current | TAKE_PROFIT (3) | `take_profit` | Take Profit |
| sell | trigger ≤ current | STOP_LOSS (4) | `stop_loss` | Stop Loss |

#### Two-step confirmation flow (Agent must follow)

`create-limit` is a write operation. **The agent MUST present a confirmation summary to the user first and only call the CLI after the user explicitly confirms.** The CLI itself does not gate (it calls BE directly); this contract is enforced at the skill layer.

**Step 1 — Show the order summary for the user to confirm.** Five top-level categories with sub-items; the agent may freely organise prose at runtime, but **no category may be dropped**:

| # | Category | Sub-items | Source |
|---|---|---|---|
| 1 | Chain | — | Human-readable chain name resolved from `--chain-id` (Arbitrum / BSC / Solana / ...) |
| 2 | Order Type | Display label per the §`strategyType` table (`Buy Dip` / `Take Profit` / `Stop Loss` / `Buy Above`). Never surface the enum name or CLI flag value | Derived per "Strategy type derivation" above |
| 3 | From token | Symbol (e.g. `USDC`); Amount (e.g. `10`) | Symbol from token metadata; Amount is raw `--amount` value |
| 4 | To token | Symbol (e.g. `ARB`); Trigger Price (e.g. `$0.10`, USD-denominated); Estimated Amount (predicted to-token amount); Value (estimated USD value) | Symbol/Trigger Price direct; Estimated Amount and Value computed by the agent — see formulas below |
| 5 | Slippage | Either `Default 15%` (user did not mention slippage) or `User-specified X%` (user explicitly said "slippage X%") | See Slippage display rules below |

**Estimated Amount / Value formulas:**

- Buy direction (BUY_DIP / CHASE_HIGH):
  - `Estimated Amount` = `from_amount` ÷ `trigger_price` (in units of to-token)
  - `Value` = `from_amount` × `from_token_USD_price` (if from is a stablecoin, ≈ `from_amount`)
- Sell direction (TAKE_PROFIT / STOP_LOSS):
  - `Estimated Amount` = `from_amount` × `trigger_price` (in units of to-token, usually a stablecoin)
  - `Value` = `from_amount` × `trigger_price` (if to is a stablecoin, equals Estimated Amount)

**Slippage display rules:**

- User did **NOT** mention slippage in the conversation → display `Slippage: Default 15%`, and **omit `--slippage`** on the CLI call (the CLI default is 15).
- User explicitly said "slippage X%" / "use X% slippage" / similar → display `Slippage: User-specified X%`, and pass `--slippage X` on the CLI call.

**Structural example** (display labels are the values from the §`strategyType` / §`status` tables; never expose enum names or CLI flag values):

```
1. Chain: Arbitrum
2. Order Type: Buy Dip
3. From: USDC 10
4. To:
   - Symbol: ARB
   - Trigger Price: $0.10
   - Estimated Amount: 100 ARB
   - Value: $10
5. Slippage: 15% (default)

If the trigger condition is not met within 7 days, this order auto-expires.

Reply confirm / change / cancel.
```

**Expiry note (mandatory)**: After the 5 categories and before the reply prompt, the agent must surface that the limit order auto-expires 7 days after creation if the trigger never fires. Default phrasing: `If the trigger condition is not met within 7 days, this order auto-expires.`

**Step 2 — Handle the user's reply:**

- User says "confirm" / "yes" / "submit" → call `onchainos strategy create-limit ...` with the `--type` derived in Step 1.
- User says "change amount = 5" / "set trigger to 0.08" / similar → update the corresponding field and **re-render Step 1** for another confirmation.
- User says "cancel" / "abort" → do NOT call the CLI; acknowledge that the order was discarded.

> Hard constraints:
> 1. **Never call `strategy create-limit` until the user has explicitly confirmed.**
> 2. `Estimated Amount` / `Value` are agent-side estimates derived from `trigger_price`, **not** BE quotes. The realised fill amount is decided at BE execution time by slippage and aggregator routing; the agent must not present these estimates as "actual fill amounts".
> 3. `--trigger-price` is a USD price. The agent must make this clear to the user to avoid confusion with "exchange rate = X from-token per 1 to-token".

### 2. `onchainos strategy cancel`

Cancel a single, batch, or all active orders. Pass exactly one of the three flags:

```
onchainos strategy cancel --order-id <id>          [--format ...]
onchainos strategy cancel --order-ids id1,id2,...  [--format ...]
onchainos strategy cancel --all                    [--format ...]
```

**Output (json):** `{ok:true,data:{updateNum:N,estimatedWaitTime:null|n}}`. `updateNum` is the count BE accepted, **not** the count that reached terminal state — re-query with `list` after the wait.

### 3. `onchainos strategy list`

```
onchainos strategy list \
  [--order-id <id>] \
  [--status active,suspended,...] \
  [--chain-id 1,501] \
  [--token <address>] \
  [--limit <int>] \
  [--cursor <string>] \
  [--strategy-mode 7] \
  [--format human|json]
```

Two modes:

- **Single order**: pass `--order-id <id>` → GET `openOrderDetail` (returns full order shape).
- **Page query**: omit `--order-id` → POST `getOpenOrder`. The active wallet's addresses are auto-supplied; pass `--limit` (max 100, default 100) and `--cursor` from the previous response's `nextCursor` for pagination.

#### `getOpenOrder` request body fields (locked)

| field | type | required | meaning |
|---|---|---|---|
| `accountId` | String | Y | Account ID, used for JWT auth. CLI auto-injects from the current session; the agent does not pass this |
| `walletAddressList` | List\<String\> | Y | Wallet address list. CLI auto-injects from the current wallet context (EVM + SOL) |
| `chainIdList` | List\<String\> | N | Chain ID filter; omit to query all chains. Mapped from `--chain-id` |
| `orderStatusList` | List\<Integer\> | N | Status filter (enum below). CLI defaults to the 5 non-terminal codes when `--status` is omitted — see §Default status filter |
| `orderTypeList` | List\<Integer\> | N | Order-type filter (BE §3.3 enum); not used in Phase 1 |
| `idList` | List\<String\> | N | Exact-match filter by order ID; no dedicated flag in Phase 1 — use `--order-id` (detail mode) instead |
| `tokenAddress` | String | N | Filter by a single token address. Mapped from `--token`. For multi-token queries, the agent calls `list` once per token (CLI rejects CSV input with a friendly error). BE schema 2026-05-09 dropped the previous multi-string `tokenAddressList`. |
| `limit` | Integer | N | Page size; BE default 100, max 100. Agent must pass `--limit 10` for default list rendering |
| `cursor` | String | N | Pagination cursor (Base64). Omit on first page; pass the previous response's `nextCursor`. Mapped from `--cursor` |

#### `status` enum (TeeSaOpenOrderStatusEnum, locked)

Full 10-state mapping — agent reads `data.list[].status` integer and looks up the display label here:

| Int value | Enum name | CLI `--status` value | Display label | Terminal? |
|---|---|---|---|---|
| -7 | EXPIRED | `expired` | Expired | Yes |
| -3 | CANCELLING | `cancelling` | Cancelling | No (transient) |
| -2 | CANCELLED | `cancelled` | Cancelled | Yes |
| -1 | FAILED | `failed` | Failed | Yes |
| 0 | TRADING | `processing` or `trading` | Trading | No |
| 1 | COMPLETED | `completed` | Completed | Yes |
| 2 | CREATING | `creating` | Creating | No |
| 3 | ACTIVE | `active` | Active | No |
| 4 | SUSPENDED | `suspended` | Suspended | No |

> SPEEDING_UP (-4) was removed 2026-05-08 — not surfaced and not a valid filter option.

> The "Display label" column is the human-readable text the agent should surface — never expose the enum name or CLI flag value (`active`, `cancelled`) directly to the user. CLI's `data.list[i].statusLabel` already returns the display label.

**Non-terminal set** (5): `{-3, 0, 2, 3, 4}` = CANCELLING / TRADING / CREATING / ACTIVE / SUSPENDED
**Terminal set** (5): `{-7, -4, -2, -1, 1}` = EXPIRED / SPEEDING_UP / CANCELLED / FAILED / COMPLETED

**Default status filter (when `--status` is omitted)**: the CLI puts `orderStatusList=[-3, 0, 2, 3, 4]` into the request body — the 5 **non-terminal** states (CANCELLING / TRADING / CREATING / ACTIVE / SUSPENDED) — and BE applies the filter server-side, returning only matching orders. Terminal orders (Cancelled / Completed / Failed / Expired) are **excluded by default**. Rationale: when a user asks "show my orders" they almost always mean live ones; surfacing historical terminal records pollutes the answer.

To see terminal orders the agent must pass `--status` explicitly:

| User intent | `--status` value to pass |
|---|---|
| "show my completed orders" | `completed` (orderStatusList=[1]) |
| "show my cancelled orders" | `cancelled` (orderStatusList=[-2]) |
| "show failed orders" | `failed` (orderStatusList=[-1]) |
| "show expired orders" | `expired` (orderStatusList=[-7]) |
| "show all orders including terminal" | `active,suspended,creating,trading,cancelling,completed,cancelled,failed,expired` (full 9) |
| "show my live orders" / no qualifier | (omit `--status` — uses non-terminal default) |

`--status` accepts comma-separated values; each entry is either an integer (e.g. `4`) or a string label (`active`, `suspended`, `processing`, `creating`, `cancelling`, `cancelled`, `completed`, `failed`, `expired`).

#### Agent rendering rules (when the user asks for orders without naming a specific status)

User prompts that match this rule include: "show my strategy orders" / "list orders" / "show my limit orders" / "what orders do I have" — i.e. any general "show me my orders" intent without a status qualifier.

Steps the agent **must** follow:

1. Run `onchainos strategy list --limit 10 --format json` (no `--status`) — the CLI puts `orderStatusList=[-3, 0, 2, 3, 4]` (non-terminal set) into the request body; BE applies the filter server-side and returns only matching orders. **Always pass `--limit 10`** for general "show my orders" queries; full pagination is opt-in via "next page" follow-up.
2. Render the response `data.list` as a Markdown table with **exactly these 8 columns** (locked):

   | Order id | Order Status | Order Type | Estimated Amount | To Token addr | Value | Trigger price | Expire after |
   |---|---|---|---|---|---|---|---|

   Per-row mapping (order matters, no extra columns):

   | Column | Source | Notes |
   |---|---|---|
   | **Order id** | `data.list[i].orderId` | — |
   | **Order Status** | `data.list[i].statusLabel` (display label per the §`status` table, e.g. `Active` / `Completed`) | Never surface the CLI flag value (`active`, `cancelled`) |
   | **Order Type** | Display label per the §`strategyType` table, derived from `data.list[i].strategyType` integer (`2 → Buy Dip` / `3 → Take Profit` / `4 → Stop Loss` / `5 → Buy Above`) | CHASE_HIGH MUST surface as **Buy Above**, not Chase High; never expose the enum name |
   | **Estimated Amount** | `data.list[i].toToken.tokenAmount` + ` ` + `data.list[i].toToken.tokenSymbol` | e.g. `0.2 SOL` |
   | **To Token addr** | `data.list[i].toToken.tokenContractAddress`, **truncated to first-6 + last-4** | EVM: `0x1234...cdef` (`0x` + 4 chars + `...` + 4 chars); Solana base58: first 6 + `...` + last 4 |
   | **Value** | `data.list[i].toToken.tokenUsd`, formatted as `<n> USD` | e.g. `16 USD` (round or 2-decimal, follow BE precision) |
   | **Trigger price** | `data.list[i].triggerInfo.triggerPrice`, prefixed with `$` | e.g. `$80`; if empty (trigger-rate path, not used in Phase 1) display `data.list[i].triggerInfo.triggerRate` |
   | **Expire after** | `data.list[i].expireTime` (13-digit ms UTC), **converted to the user's current timezone**, formatted `MM/DD/YYYY HH:MM:SS` | e.g. `05/15/2026 17:50:49` (semantically = createTime + 7 days by default) |

   Sample row (Solana SOL→USDC take_profit):

   ```
   | 17262791359882688 | Active | Take Profit | 0.2 SOL | 9xQeWv...vEjz | 16 USD | $80 | 05/15/2026 17:50:49 |
   ```

   Address shortening rules:
   - EVM (`0x` prefix): first 6 chars (`0x` + 4) + `...` + last 4 chars
   - Solana / other non-prefixed base58: first 6 + `...` + last 4
   - Strings shorter than 10 chars: do not truncate; display verbatim

   Expire timezone conversion:
   - `expireTime` from BE is a UTC millisecond timestamp
   - The agent **must convert to the user's current local timezone** at render time (e.g. JS `Intl.DateTimeFormat`, Rust `chrono::Local`, or equivalent)
   - Fixed format: `MM/DD/YYYY HH:MM:SS`, 24-hour clock

3. After the table, append a **single combined reminder** covering pagination + status filter. Include the pagination line **only when `nextCursor` is non-empty**.

   The reminder must convey two things (canonical EN; the agent translates per §Output language convention):

   > Showing live orders by default (10 per page).
   > - Reply "next page" to load more.
   > - To filter by a specific state, ask for orders by their **Display label** — e.g. `Completed`, `Cancelled`, `Failed`, `Expired`. Example: "show my completed orders" → I'll re-query with that filter.

   **Rendering rule (locked)**:
   - Use Display labels from the §`status` table (`Completed` / `Cancelled` / `Failed` / `Expired`) when listing the filter options to the user.
   - **Never** spell out CLI flag values (`completed`, `cancelled`, `failed`, `expired`) or enum names (`COMPLETED`) in user-facing prose — those are internal.
   - When the user is in Chinese, the agent renders these Display labels in Chinese (`已完成`, `已取消`, `失败`, `已过期`, `加速中`) per §Output language convention.

   If `nextCursor` is empty (no more pages), drop the "next page" bullet and keep only the status-filter bullet.

4. If the user replies "next page" / similar, re-run with `--limit 10 --cursor <nextCursor>` carrying the previous response's `nextCursor`. Render with the same table format.

5. If the user names a specific status (any of the 10 labels), re-run as `list --limit 10 --status <label>` (single value) and render the same table. Drop the status-filter bullet from the reminder; keep the pagination bullet if `nextCursor` is non-empty.

### 4. `onchainos strategy resume`

```
onchainos strategy resume                          # auto-discover all SUSPENDED + canResume=true on active wallet
onchainos strategy resume --order-ids id1,id2      # explicit
```

When ids are omitted, the CLI runs `list` filtered to `status=4` and keeps only orders whose `canResume` flag is true; the discovered ids are then submitted to `reactivate`. After resume, the agent should advise the user that orders whose trigger condition was already met may execute immediately — re-query with `list` to confirm.

## Error code → Agent action

The CLI surfaces the BE error code in human-readable form. Map each code to a recommended next step:

| Code | Name | What the agent should do |
|---|---|---|
| 100 | REQUEST_PARAM_ERROR | Surface the BE message; ask the user to fix the offending flag |
| 10026 | JWT_TOKEN_VERIFY_FAILED | Suggest `onchainos wallet login` then retry |
| 10106 | CHAIN_NOT_SUPPORT_ERROR | Tell the user the chain is not supported; suggest a supported alternative |
| 60002 | NO_ORDER_FOUND | Cancel/resume target id is wrong or already terminal — suggest `list` |
| 60003 | LIMIT_ORDER_NO_AUTHORITY | Trader Mode may not be activated yet; the next CLI call will trigger SD-A automatically — retry once |
| 60006 | LIMIT_ORDER_OUT_LIMIT_FAIL | Pending count is at the per-account limit; suggest `cancel --all` or `cancel --order-id` first |
| 60009 | LIMIT_ORDER_ILLIQUIDITY_ERROR | No liquidity for the pair at the trigger; suggest a different pair or wider trigger |
| 60014 | LIMIT_ORDER_EXPIRED_CANNOT_OPERATE | Order already expired |
| 60015 | LIMIT_ORDER_PENDING_CANNOT_OPERATE | Order is mid-lifecycle; wait for terminal state |
| 60017 | LIMIT_ORDER_SUCCESS_CANNOT_OPERATE | Order already completed |
| 60018 | LIMIT_ORDER_TEE_SA_VERSION_UPGRADE_REQUIRED | Transparent — CLI handles via SD-A retry; the agent should NOT see this code in normal flow. If it leaks, just retry the same command |
| 60030 | QUOTA_EXCEEDED | Account-level quota reached |
| 100007 | TEE_SIGN_FAILURE | Transient TEE issue — retry once |
| 100012 | LIMIT_ORDER_INSUFFICIENT_BALANCE | Insufficient balance; suggest checking with `onchainos wallet balance` |

> **Match by integer code, not msg string.** The msg text is for humans and may change.

## Execution event codes (`executionHistoryList[].code`)

A separate stream from the BE error codes above. Emitted by the TEE swap-trade engine while it attempts to execute an active order. Read the **latest** entry first; older ones are historical context.

> Full catalog (all 3xxx + legacy 2xxx) lives in `references/execution-event-codes.md` — load it whenever the user inspects a stuck/failed order.

Hot codes the agent should recognise inline. Use the **message** column verbatim when surfacing to the user (matches OKX wallet UI wording):

| code | name | message | what the agent should do |
|---|---|---|---|
| 0 | tradeSuccessed | Trade successful | report success; surface `txHash` + explorer link |
| 3013 | insufficientBalance | Insufficient funds in wallet | suggest topping up or recreating with smaller amount |
| 3014 | insufficientLamports | Insufficient funds for network fee | tell user to fund chain native fee token |
| 3015 | exceedSlippage | Price exceeded slippage at trade | suggest widening `--slippage` |
| 3016 | noLiquidty | No quote due to low liquidity | non-transient — suggest different pair, smaller amount, wider trigger, or different chain |
| 3017 | unableQuote | Unable to fetch a quote | retry; if recurring, treat like 3016 |
| 3019 | riskToken | Failed to trade due to risky token | terminal — order won't execute |
| 3020 | blackAddress | Failed to trade due to blocklisted address | terminal — surface explicitly |
| 3023 | orderExpired | Limit order expired | recreate with longer `--expires-in` |

**Pattern**: when the same code recurs every ~10s without a `txHash` ever appearing, the engine is in a soft retry loop. Surface the latest reason and ask the user whether to wait, cancel, or adjust parameters — don't let it grind silently. Cancel after a few cycles if the cause is non-transient (3016, 3019, 3020, 3023).

## Async wait pattern

`create-limit` and `cancel` return after the request has been **accepted**, not after the order reached a terminal state. The CLI surfaces `estimatedWaitTime` (seconds, BE-supplied — typically 0 for Solana, ~3 for BSC, ~12 for ETH-class chains).

**Agent recipe:**
1. Run the subcommand.
2. If `estimatedWaitTime > 0`, **wait that many seconds** (single sleep, no busy-loop).
3. Re-query with `onchainos strategy list --order-id <orderId>` to read the final state.
4. If still pending after 2× the wait time, surface the partial state to the user; do not loop indefinitely.

> Do **not** run a long polling loop. The CLI is not designed for that; the BE backs the order finalisation off-chain and one targeted re-query is sufficient in normal conditions.

## SA activation transparency

Trader Mode upgrade / re-upgrade is performed transparently by the CLI:

- On `create-limit` or `resume`, if the BE returns code `60018` (`UPGRADE_REQUIRED`), the CLI calls the Agentic Wallet attestation endpoints (`getAttestDocHex` → ed25519 sign with the session key → `registerTeeInfo`), then retries the original op once. On success the user sees `Trader Mode activated.` followed by the normal command output.
- The agent should not ask the user to "activate Trader Mode" first — the CLI does it on demand.
- If activation **fails**, the original command aborts and the activation error is surfaced. Suggest `onchainos wallet status` to inspect the session.

## Output format conventions

All subcommands accept `--format human` (default) or `--format json`.

`json` mode emits the standard onchainos JSON envelope `{ok: true, data: { ... }}` so an agent can parse the output deterministically. Use `human` for chat-style replies; use `json` when piping to another tool or step.

## Phase 1 limitations

| Item | Phase 1 status |
|---|---|
| Symbol → address resolution for `--from-token` / `--to-token` | Not in scope; pass token addresses directly |
| Custom preset (advanced fee tiers, MEV mode, dexId filter) | Default preset only; advanced fields TBC with BE |
| Events stream / cursor consumption | `eventCursor` is surfaced verbatim; no consumer in Phase 1 |
| `cancel --all` source-channel filter (KD-009) | Pass-through to BE default; CLI does not pre-filter |
| Multi-account batch | Out of scope; CLI uses the active account only |
| `get_account_status` (PRD §5.1) | Intentionally not implemented. SA activation / expiry is handled transparently inside the 60018 (UPGRADE_REQUIRED) flow — the CLI runs SD-A and retries silently. The agent does not need to query SA state up-front; just call the intended subcommand and let the CLI handle activation on demand. |
