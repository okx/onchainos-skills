# Routing smoke results

Run date: 2026-08-18

| # | Prompt | Expected route | Actual blind route | Result |
|---|---|---|---|---|
| 1 | 帮我注册一个提供钱包分析服务的 ASP。 | `okx-ai` → `identity-core.md` → `identity-register.md` + `identity-invariants.md`; service references on demand | Matched the expected skill and complete reference chain | PASS |
| 2 | 把 Agent #42 的 A2MCP 服务请求方法从 POST /scan 改成 POST https://api.example.com/scan。 | `okx-ai` → core/update/invariants → CLI reference immediately before the first identity call → service contract/A2MCP → listing QA at its gate | Initial run omitted update, invariants, and listing QA. After the router/CLI-reference reinforcement, a blind rerun of the same prompt returned the complete ordered chain and conditional timing | PASS (rerun) |
| 3 | 帮我查 ETH 当前价格，再看看这个代币合约是否安全。 | Do not trigger `okx-ai`; route price to `okx-dex-market` and safety scan to `okx-agentic-wallet` | Matched both expected non-`okx-ai` routes | PASS |

Current pass rate after the exact-prompt rerun: 3/3 (100%). The initial failure remains recorded in
row 2. Each prompt was run blind by an independent read-only routing agent; no expected answer was
supplied and no CLI command or external mutation was performed.
