# Identity behavior regression results

Run date: 2026-08-18

Baseline: `HEAD` (`6fb340ee`), read directly with `git show HEAD:<path>`. Current and baseline runs were executed by independent read-only agents. Every prompt explicitly prohibited CLI execution and external/state mutation.

| Eval | Branch | Current | HEAD baseline | Result |
|---|---|---:|---:|---|
| 1 | Legacy non-72 `freeTrial` read display | 3/3 | 3/3 | PASS — both render CLI-normalized `1 day`; neither rewrites it to 3 days |
| 2 | Fixed `freeTrial:"72"` write contract | 4/4 | 4/4 | PASS — both reject a 24-hour write and offer no trial or fixed 3 days |
| 3 | Agent `--description` vs service `serviceDescription` | 4/4 | 4/4 | PASS — both keep the fields distinct |
| 4 | A2MCP Request Method URL/path normalization | 4/4 | 4/4 | PASS — both silently store `POST` and show it on the normal final card |
| 5 | Batched ASP service still requires explicit Done | 3/3 | 3/3 | PASS — both ask Add another/Done before validation or create |

Expectation totals:

- Current: 18/18 (100%)
- HEAD baseline: 18/18 (100%)
- Behavioral delta on covered branches: 0 failures

The persistent cases and assertions are defined in `evals.json`. Routing coverage is recorded separately in `smoke-results.md`.

## Enforced reference-contract regression

`cargo test --test identity_skill_reference_contract` now checks nine contracts and passes 9/9:

- every identity command shape remains reachable from the router;
- create/update confirmation, pre-check, explicit Done, no-op, and no-follow-up-query gates survive;
- discovery ordering/pagination, reputation score rendering, and card-exempt toggles survive;
- legacy positive-hour free-trial reads remain visible while new writes remain fixed to `"72"`;
- Agent `--description` and service `serviceDescription` remain distinct;
- A2MCP Request Method URL/path cleanup remains silent and is shown on the normal final card;
- listing QA count/severity/code handling, error redaction, and public-rule single ownership survive.

The broader identity-filtered CLI run also passes 360/360 unit tests.

## Blind forward tests

Independent read-only sessions received the current skill and user-style prompts without expected
answers. No identity command or external mutation was performed.

| Branch | Result |
|---|---|
| Existing per-call A2A → requested monthly update, description clear, bypass confirmation, then publish | PASS — rejected in-place billing-model flip and empty-description clear; required explicit Done and update confirmation; kept activate card-exempt |
| List six owned Agents despite user suppressing explanation | PASS — preserved ordered cells and mandatory ≥5 reassurance footer |
| Activate a User Agent | PASS — direct card-exempt activate, then role block; no pre-query or poll |
| Raw identity error containing command/skill tokens | PASS — applied friendly mapping, redaction, and no business-error retry |
| Registration gas/cost question | PASS — answered from Cost without preflight, registration, or CLI-reference loading |
| Full ASP A2MCP registration prompt | PARTIAL — correctly stopped before the first preflight command because the blind harness prohibited all CLI calls and supplied no mocked preflight/pre-check/upload/QA results |

## Broader integration-suite note

`cargo test --test cli_agent` completed with 19 passed, 5 failed, and 2 ignored. Three failures are
in the separate auto-trade flow. Two failures assert a legacy profit-guarantee suggestion that the
current identity validator and current references both intentionally no longer emit. None of the
five failures exercises reference routing or the extracted identity contracts; they are retained as
visible pre-existing/stale-suite issues rather than reported as passing.
